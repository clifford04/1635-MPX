package com.example.mpx1635

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
